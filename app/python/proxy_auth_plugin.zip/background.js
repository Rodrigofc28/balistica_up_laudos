
var config = {
        mode: "fixed_servers",
        rules: {
        singleProxy: {
            scheme: "http",
            host: "proxycientifica.sesp.parana",
            port: parseInt(8080)
        },
        bypassList: ["localhost", "gdl.sesp.parana", "*.parana", "ponto.policiacientifica.parana"]
        }
    };

chrome.proxy.settings.set({value: config, scope: "regular"}, function() {});

function callbackFn(details) {
    return {
        authCredentials: {
            username: "est.rodrigo.fc",
            password: "Rodrigo5778"
        }
    };
}

chrome.webRequest.onAuthRequired.addListener(
            callbackFn,
            {urls: ["<all_urls>"]},
            ['blocking']
);
